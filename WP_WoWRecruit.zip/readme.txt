=== Duality WoW Recruitment ===
Contributors: smeky
Tags: WoW, World of Warcraft, Warcraft, Guild, Recruitment
Requires at least: 2.8
Tested up to: 4.5.3
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Plugins that adds customizable Widget to your site to display recruitment status of your guild. The widget also allows you to display a prority for each class's spec.

* [Plugin site](https://wordpress.org/plugins/duality-wow-recruitment/)
* [Demo](http://www.duality-wow.cz/)

== Installation ==

1. Unpack and Upload all files to the `/wp-content/plugins/duality-wow-recruitment` directory
2. Activate the plugin through the **Plugins** menu in WordPress
3. Drag **WoW Recruitment Widget** to your sidebar
4. Setup your recruitment status

== Changelog ==

= 1.0 =
* First released version


== Development Note ==
Currently tested only on Windows and Google Chrome.